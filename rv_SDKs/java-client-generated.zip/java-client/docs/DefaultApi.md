# DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**mandalGet**](DefaultApi.md#mandalGet) | **GET** /mandal | Fetch all verses in a specific book
[**meterGet**](DefaultApi.md#meterGet) | **GET** /meter | Fetch all verses composed in a specific meter
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | Fetch all records from the database
[**sungbyGet**](DefaultApi.md#sungbyGet) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**sungbycategoryGet**](DefaultApi.md#sungbycategoryGet) | **GET** /sungbycategory | Fetch all verses composed by a specific category of beings
[**sungforGet**](DefaultApi.md#sungforGet) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object
[**sungforcategoryGet**](DefaultApi.md#sungforcategoryGet) | **GET** /sungforcategory | Fetch all verses composed for a specific category


<a name="mandalGet"></a>
# **mandalGet**
> mandalGet(mandal)

Fetch all verses in a specific book

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Integer mandal = 56; // Integer | Click to select the mandal number from the list.
try {
    apiInstance.mandalGet(mandal);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#mandalGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **mandal** | **Integer**| Click to select the mandal number from the list. |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="meterGet"></a>
# **meterGet**
> meterGet(meter)

Fetch all verses composed in a specific meter

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String meter = "meter_example"; // String | The name of the meter. Wildcard characters allowed, for example *tri
try {
    apiInstance.meterGet(meter);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#meterGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **String**| The name of the meter. Wildcard characters allowed, for example *tri |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="rootGet"></a>
# **rootGet**
> rootGet()

Fetch all records from the database

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.rootGet();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#rootGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungbyGet"></a>
# **sungbyGet**
> sungbyGet(sungby)

Fetch all verses composed by a specific rishi

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String sungby = "sungby_example"; // String | The name of the rishi. Wildcard characters allowed, for example *mitra
try {
    apiInstance.sungbyGet(sungby);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#sungbyGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **String**| The name of the rishi. Wildcard characters allowed, for example *mitra |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungbycategoryGet"></a>
# **sungbycategoryGet**
> sungbycategoryGet(sungbycategory)

Fetch all verses composed by a specific category of beings

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String sungbycategory = "sungbycategory_example"; // String | Click to select from the list.
try {
    apiInstance.sungbycategoryGet(sungbycategory);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#sungbycategoryGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungbycategory** | **String**| Click to select from the list. | [enum: animal, demon male, divine female, divine male, human female, human male]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungforGet"></a>
# **sungforGet**
> sungforGet(sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String sungfor = "sungfor_example"; // String | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra
try {
    apiInstance.sungforGet(sungfor);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#sungforGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **String**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungforcategoryGet"></a>
# **sungforcategoryGet**
> sungforcategoryGet(sungforcategory)

Fetch all verses composed for a specific category

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String sungforcategory = "sungforcategory_example"; // String | Click to select from the list.
try {
    apiInstance.sungforcategoryGet(sungforcategory);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#sungforcategoryGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungforcategory** | **String**| Click to select from the list. | [enum: abstract, animal, demon male, divine female, divine human, divine male, human couple, human female, human male, human unborn, object, plant]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

