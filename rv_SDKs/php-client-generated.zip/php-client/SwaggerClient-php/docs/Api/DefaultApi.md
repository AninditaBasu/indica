# Swagger\Client\DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**meterGet**](DefaultApi.md#meterGet) | **GET** /meter | Fetch all verses composed in a specific meter
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | Fetch all records from the database
[**sungbyGet**](DefaultApi.md#sungbyGet) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**sungforGet**](DefaultApi.md#sungforGet) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object


# **meterGet**
> meterGet($meter)

Fetch all verses composed in a specific meter

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$meter = "meter_example"; // string | The name of the meter. Wildcard characters allowed, for example *tri

try {
    $apiInstance->meterGet($meter);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->meterGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **string**| The name of the meter. Wildcard characters allowed, for example *tri |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **rootGet**
> rootGet()

Fetch all records from the database

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->rootGet();
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->rootGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **sungbyGet**
> sungbyGet($sungby)

Fetch all verses composed by a specific rishi

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$sungby = "sungby_example"; // string | The name of the rishi. Wildcard characters allowed, for example *mitra

try {
    $apiInstance->sungbyGet($sungby);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->sungbyGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **string**| The name of the rishi. Wildcard characters allowed, for example *mitra |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **sungforGet**
> sungforGet($sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$sungfor = "sungfor_example"; // string | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra

try {
    $apiInstance->sungforGet($sungfor);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->sungforGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **string**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

