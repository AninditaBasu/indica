# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MandalGet**](DefaultApi.md#mandalget) | **GET** /mandal | Fetch all verses in a specific book
[**MeterGet**](DefaultApi.md#meterget) | **GET** /meter | Fetch all verses composed in a specific meter
[**RootGet**](DefaultApi.md#rootget) | **GET** / | Fetch all records from the database
[**SungbyGet**](DefaultApi.md#sungbyget) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**SungbycategoryGet**](DefaultApi.md#sungbycategoryget) | **GET** /sungbycategory | Fetch all verses composed by a specific category of beings
[**SungforGet**](DefaultApi.md#sungforget) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object
[**SungforcategoryGet**](DefaultApi.md#sungforcategoryget) | **GET** /sungforcategory | Fetch all verses composed for a specific category


<a name="mandalget"></a>
# **MandalGet**
> void MandalGet (int? mandal)

Fetch all verses in a specific book

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MandalGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var mandal = 56;  // int? | Click to select the mandal number from the list.

            try
            {
                // Fetch all verses in a specific book
                apiInstance.MandalGet(mandal);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.MandalGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **mandal** | **int?**| Click to select the mandal number from the list. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="meterget"></a>
# **MeterGet**
> void MeterGet (string meter)

Fetch all verses composed in a specific meter

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MeterGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var meter = meter_example;  // string | The name of the meter. Wildcard characters allowed, for example *tri

            try
            {
                // Fetch all verses composed in a specific meter
                apiInstance.MeterGet(meter);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.MeterGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **string**| The name of the meter. Wildcard characters allowed, for example *tri | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rootget"></a>
# **RootGet**
> void RootGet ()

Fetch all records from the database

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RootGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                // Fetch all records from the database
                apiInstance.RootGet();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.RootGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sungbyget"></a>
# **SungbyGet**
> void SungbyGet (string sungby)

Fetch all verses composed by a specific rishi

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SungbyGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var sungby = sungby_example;  // string | The name of the rishi. Wildcard characters allowed, for example *mitra

            try
            {
                // Fetch all verses composed by a specific rishi
                apiInstance.SungbyGet(sungby);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SungbyGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **string**| The name of the rishi. Wildcard characters allowed, for example *mitra | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sungbycategoryget"></a>
# **SungbycategoryGet**
> void SungbycategoryGet (string sungbycategory)

Fetch all verses composed by a specific category of beings

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SungbycategoryGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var sungbycategory = sungbycategory_example;  // string | Click to select from the list.

            try
            {
                // Fetch all verses composed by a specific category of beings
                apiInstance.SungbycategoryGet(sungbycategory);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SungbycategoryGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungbycategory** | **string**| Click to select from the list. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sungforget"></a>
# **SungforGet**
> void SungforGet (string sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SungforGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var sungfor = sungfor_example;  // string | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra

            try
            {
                // Fetch all verses addressed to a specific god, goddess, or object
                apiInstance.SungforGet(sungfor);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SungforGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **string**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sungforcategoryget"></a>
# **SungforcategoryGet**
> void SungforcategoryGet (string sungforcategory)

Fetch all verses composed for a specific category

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SungforcategoryGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var sungforcategory = sungforcategory_example;  // string | Click to select from the list.

            try
            {
                // Fetch all verses composed for a specific category
                apiInstance.SungforcategoryGet(sungforcategory);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SungforcategoryGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungforcategory** | **string**| Click to select from the list. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

