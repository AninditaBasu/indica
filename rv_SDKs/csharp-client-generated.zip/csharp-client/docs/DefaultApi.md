# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MeterGet**](DefaultApi.md#meterget) | **GET** /meter | Fetch all verses composed in a specific meter
[**RootGet**](DefaultApi.md#rootget) | **GET** / | Fetch all records from the database
[**SungbyGet**](DefaultApi.md#sungbyget) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**SungforGet**](DefaultApi.md#sungforget) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object


<a name="meterget"></a>
# **MeterGet**
> void MeterGet (string meter)

Fetch all verses composed in a specific meter

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MeterGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var meter = meter_example;  // string | The name of the meter. Wildcard characters allowed, for example *tri

            try
            {
                // Fetch all verses composed in a specific meter
                apiInstance.MeterGet(meter);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.MeterGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **string**| The name of the meter. Wildcard characters allowed, for example *tri | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rootget"></a>
# **RootGet**
> void RootGet ()

Fetch all records from the database

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RootGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                // Fetch all records from the database
                apiInstance.RootGet();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.RootGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sungbyget"></a>
# **SungbyGet**
> void SungbyGet (string sungby)

Fetch all verses composed by a specific rishi

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SungbyGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var sungby = sungby_example;  // string | The name of the rishi. Wildcard characters allowed, for example *mitra

            try
            {
                // Fetch all verses composed by a specific rishi
                apiInstance.SungbyGet(sungby);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SungbyGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **string**| The name of the rishi. Wildcard characters allowed, for example *mitra | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="sungforget"></a>
# **SungforGet**
> void SungforGet (string sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SungforGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var sungfor = sungfor_example;  // string | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra

            try
            {
                // Fetch all verses addressed to a specific god, goddess, or object
                apiInstance.SungforGet(sungfor);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SungforGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **string**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

