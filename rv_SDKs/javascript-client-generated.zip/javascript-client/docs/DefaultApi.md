# RvApi.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**mandalGet**](DefaultApi.md#mandalGet) | **GET** /mandal | Fetch all verses in a specific book
[**meterGet**](DefaultApi.md#meterGet) | **GET** /meter | Fetch all verses composed in a specific meter
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | Fetch all records from the database
[**sungbyGet**](DefaultApi.md#sungbyGet) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**sungbycategoryGet**](DefaultApi.md#sungbycategoryGet) | **GET** /sungbycategory | Fetch all verses composed by a specific category of beings
[**sungforGet**](DefaultApi.md#sungforGet) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object
[**sungforcategoryGet**](DefaultApi.md#sungforcategoryGet) | **GET** /sungforcategory | Fetch all verses composed for a specific category


<a name="mandalGet"></a>
# **mandalGet**
> mandalGet(mandal)

Fetch all verses in a specific book

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var mandal = 56; // Number | Click to select the mandal number from the list.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.mandalGet(mandal, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **mandal** | **Number**| Click to select the mandal number from the list. | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="meterGet"></a>
# **meterGet**
> meterGet(meter)

Fetch all verses composed in a specific meter

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var meter = "meter_example"; // String | The name of the meter. Wildcard characters allowed, for example *tri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.meterGet(meter, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **String**| The name of the meter. Wildcard characters allowed, for example *tri | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="rootGet"></a>
# **rootGet**
> rootGet()

Fetch all records from the database

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.rootGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungbyGet"></a>
# **sungbyGet**
> sungbyGet(sungby)

Fetch all verses composed by a specific rishi

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var sungby = "sungby_example"; // String | The name of the rishi. Wildcard characters allowed, for example *mitra


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.sungbyGet(sungby, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **String**| The name of the rishi. Wildcard characters allowed, for example *mitra | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungbycategoryGet"></a>
# **sungbycategoryGet**
> sungbycategoryGet(sungbycategory)

Fetch all verses composed by a specific category of beings

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var sungbycategory = "sungbycategory_example"; // String | Click to select from the list.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.sungbycategoryGet(sungbycategory, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungbycategory** | **String**| Click to select from the list. | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungforGet"></a>
# **sungforGet**
> sungforGet(sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var sungfor = "sungfor_example"; // String | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.sungforGet(sungfor, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **String**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungforcategoryGet"></a>
# **sungforcategoryGet**
> sungforcategoryGet(sungforcategory)

Fetch all verses composed for a specific category

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var sungforcategory = "sungforcategory_example"; // String | Click to select from the list.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.sungforcategoryGet(sungforcategory, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungforcategory** | **String**| Click to select from the list. | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

