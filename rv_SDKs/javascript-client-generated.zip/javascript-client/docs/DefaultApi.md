# RvApi.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**meterGet**](DefaultApi.md#meterGet) | **GET** /meter | Fetch all verses composed in a specific meter
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | Fetch all records from the database
[**sungbyGet**](DefaultApi.md#sungbyGet) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**sungforGet**](DefaultApi.md#sungforGet) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object


<a name="meterGet"></a>
# **meterGet**
> meterGet(meter)

Fetch all verses composed in a specific meter

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var meter = "meter_example"; // String | The name of the meter. Wildcard characters allowed, for example *tri


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.meterGet(meter, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **String**| The name of the meter. Wildcard characters allowed, for example *tri | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="rootGet"></a>
# **rootGet**
> rootGet()

Fetch all records from the database

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.rootGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungbyGet"></a>
# **sungbyGet**
> sungbyGet(sungby)

Fetch all verses composed by a specific rishi

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var sungby = "sungby_example"; // String | The name of the rishi. Wildcard characters allowed, for example *mitra


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.sungbyGet(sungby, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **String**| The name of the rishi. Wildcard characters allowed, for example *mitra | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="sungforGet"></a>
# **sungforGet**
> sungforGet(sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var sungfor = "sungfor_example"; // String | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.sungforGet(sungfor, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **String**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

