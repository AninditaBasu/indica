# swagger_client.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/rv*

Method | HTTP request | Description
------------- | ------------- | -------------
[**mandal_get**](DefaultApi.md#mandal_get) | **GET** /mandal | Fetch all verses in a specific book
[**meter_get**](DefaultApi.md#meter_get) | **GET** /meter | Fetch all verses composed in a specific meter
[**root_get**](DefaultApi.md#root_get) | **GET** / | Fetch all records from the database
[**sungby_get**](DefaultApi.md#sungby_get) | **GET** /sungby | Fetch all verses composed by a specific rishi
[**sungbycategory_get**](DefaultApi.md#sungbycategory_get) | **GET** /sungbycategory | Fetch all verses composed by a specific category of beings
[**sungfor_get**](DefaultApi.md#sungfor_get) | **GET** /sungfor | Fetch all verses addressed to a specific god, goddess, or object
[**sungforcategory_get**](DefaultApi.md#sungforcategory_get) | **GET** /sungforcategory | Fetch all verses composed for a specific category


# **mandal_get**
> mandal_get(mandal)

Fetch all verses in a specific book

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
mandal = 56 # int | Click to select the mandal number from the list.

try:
    # Fetch all verses in a specific book
    api_instance.mandal_get(mandal)
except ApiException as e:
    print("Exception when calling DefaultApi->mandal_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **mandal** | **int**| Click to select the mandal number from the list. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **meter_get**
> meter_get(meter)

Fetch all verses composed in a specific meter

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
meter = 'meter_example' # str | The name of the meter. Wildcard characters allowed, for example *tri

try:
    # Fetch all verses composed in a specific meter
    api_instance.meter_get(meter)
except ApiException as e:
    print("Exception when calling DefaultApi->meter_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **meter** | **str**| The name of the meter. Wildcard characters allowed, for example *tri | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **root_get**
> root_get()

Fetch all records from the database

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()

try:
    # Fetch all records from the database
    api_instance.root_get()
except ApiException as e:
    print("Exception when calling DefaultApi->root_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sungby_get**
> sungby_get(sungby)

Fetch all verses composed by a specific rishi

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
sungby = 'sungby_example' # str | The name of the rishi. Wildcard characters allowed, for example *mitra

try:
    # Fetch all verses composed by a specific rishi
    api_instance.sungby_get(sungby)
except ApiException as e:
    print("Exception when calling DefaultApi->sungby_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungby** | **str**| The name of the rishi. Wildcard characters allowed, for example *mitra | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sungbycategory_get**
> sungbycategory_get(sungbycategory)

Fetch all verses composed by a specific category of beings

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
sungbycategory = 'sungbycategory_example' # str | Click to select from the list.

try:
    # Fetch all verses composed by a specific category of beings
    api_instance.sungbycategory_get(sungbycategory)
except ApiException as e:
    print("Exception when calling DefaultApi->sungbycategory_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungbycategory** | **str**| Click to select from the list. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sungfor_get**
> sungfor_get(sungfor)

Fetch all verses addressed to a specific god, goddess, or object

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
sungfor = 'sungfor_example' # str | The name of the god, goddess, or object. Wildcard characters allowed, for example *dra

try:
    # Fetch all verses addressed to a specific god, goddess, or object
    api_instance.sungfor_get(sungfor)
except ApiException as e:
    print("Exception when calling DefaultApi->sungfor_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungfor** | **str**| The name of the god, goddess, or object. Wildcard characters allowed, for example *dra | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sungforcategory_get**
> sungforcategory_get(sungforcategory)

Fetch all verses composed for a specific category

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
sungforcategory = 'sungforcategory_example' # str | Click to select from the list.

try:
    # Fetch all verses composed for a specific category
    api_instance.sungforcategory_get(sungforcategory)
except ApiException as e:
    print("Exception when calling DefaultApi->sungforcategory_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sungforcategory** | **str**| Click to select from the list. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

