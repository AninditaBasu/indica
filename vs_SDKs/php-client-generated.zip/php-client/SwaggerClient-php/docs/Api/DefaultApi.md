# Swagger\Client\DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/vs*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoryGet**](DefaultApi.md#categoryGet) | **GET** /category | Fetch all words in a specific category
[**descriptionGet**](DefaultApi.md#descriptionGet) | **GET** /description | Fetch all meanings that contain a specific string
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | Fetch all records from the database
[**wordGet**](DefaultApi.md#wordGet) | **GET** /word | Fetch the meaning of a specific word


# **categoryGet**
> categoryGet($category)

Fetch all words in a specific category

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$category = "category_example"; // string | Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation.

try {
    $apiInstance->categoryGet($category);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->categoryGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **string**| Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation. |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **descriptionGet**
> descriptionGet($description)

Fetch all meanings that contain a specific string

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$description = "description_example"; // string | The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*.

try {
    $apiInstance->descriptionGet($description);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->descriptionGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **description** | **string**| The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*. |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **rootGet**
> rootGet()

Fetch all records from the database

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->rootGet();
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->rootGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **wordGet**
> wordGet($word)

Fetch the meaning of a specific word

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\DefaultApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$word = "word_example"; // string | The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*.

try {
    $apiInstance->wordGet($word);
} catch (Exception $e) {
    echo 'Exception when calling DefaultApi->wordGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **word** | **string**| The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*. |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

