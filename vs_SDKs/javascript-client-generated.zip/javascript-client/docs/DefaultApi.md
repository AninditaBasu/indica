# RvApi.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/vs*

Method | HTTP request | Description
------------- | ------------- | -------------
[**categoryGet**](DefaultApi.md#categoryGet) | **GET** /category | Fetch all words in a specific category
[**descriptionGet**](DefaultApi.md#descriptionGet) | **GET** /description | Fetch all meanings that contain a specific string
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | Fetch all records from the database
[**wordGet**](DefaultApi.md#wordGet) | **GET** /word | Fetch the meaning of a specific word


<a name="categoryGet"></a>
# **categoryGet**
> categoryGet(category)

Fetch all words in a specific category

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var category = "category_example"; // String | Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.categoryGet(category, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **String**| Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation. | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="descriptionGet"></a>
# **descriptionGet**
> descriptionGet(description)

Fetch all meanings that contain a specific string

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var description = "description_example"; // String | The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.descriptionGet(description, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **description** | **String**| The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*. | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="rootGet"></a>
# **rootGet**
> rootGet()

Fetch all records from the database

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.rootGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="wordGet"></a>
# **wordGet**
> wordGet(word)

Fetch the meaning of a specific word

### Example
```javascript
var RvApi = require('rv_api');

var apiInstance = new RvApi.DefaultApi();

var word = "word_example"; // String | The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*.


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.wordGet(word, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **word** | **String**| The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*. | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

