# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/vs*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CategoryGet**](DefaultApi.md#categoryget) | **GET** /category | Fetch all words in a specific category
[**DescriptionGet**](DefaultApi.md#descriptionget) | **GET** /description | Fetch all meanings that contain a specific string
[**RootGet**](DefaultApi.md#rootget) | **GET** / | Fetch all records from the database
[**WordGet**](DefaultApi.md#wordget) | **GET** /word | Fetch the meaning of a specific word


<a name="categoryget"></a>
# **CategoryGet**
> void CategoryGet (string category)

Fetch all words in a specific category

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CategoryGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var category = category_example;  // string | Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation.

            try
            {
                // Fetch all words in a specific category
                apiInstance.CategoryGet(category);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.CategoryGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **string**| Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="descriptionget"></a>
# **DescriptionGet**
> void DescriptionGet (string description)

Fetch all meanings that contain a specific string

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DescriptionGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var description = description_example;  // string | The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*.

            try
            {
                // Fetch all meanings that contain a specific string
                apiInstance.DescriptionGet(description);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.DescriptionGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **description** | **string**| The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="rootget"></a>
# **RootGet**
> void RootGet ()

Fetch all records from the database

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RootGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                // Fetch all records from the database
                apiInstance.RootGet();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.RootGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="wordget"></a>
# **WordGet**
> void WordGet (string word)

Fetch the meaning of a specific word

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class WordGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var word = word_example;  // string | The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*.

            try
            {
                // Fetch the meaning of a specific word
                apiInstance.WordGet(word);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.WordGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **word** | **string**| The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

