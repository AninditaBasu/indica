# swagger_client.DefaultApi

All URIs are relative to *https://sheetlabs.com/RV/vs*

Method | HTTP request | Description
------------- | ------------- | -------------
[**category_get**](DefaultApi.md#category_get) | **GET** /category | Fetch all words in a specific category
[**description_get**](DefaultApi.md#description_get) | **GET** /description | Fetch all meanings that contain a specific string
[**root_get**](DefaultApi.md#root_get) | **GET** / | Fetch all records from the database
[**word_get**](DefaultApi.md#word_get) | **GET** /word | Fetch the meaning of a specific word


# **category_get**
> category_get(category)

Fetch all words in a specific category

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
category = 'category_example' # str | Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation.

try:
    # Fetch all words in a specific category
    api_instance.category_get(category)
except ApiException as e:
    print("Exception when calling DefaultApi->category_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **str**| Example category name: disease. Wildcards allowed; example: dis*. For a list of valid categories, see the documentation. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **description_get**
> description_get(description)

Fetch all meanings that contain a specific string

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
description = 'description_example' # str | The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*.

try:
    # Fetch all meanings that contain a specific string
    api_instance.description_get(description)
except ApiException as e:
    print("Exception when calling DefaultApi->description_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **description** | **str**| The string you are looking for in the word meaning, for example, chariot. Wildcards allowed; example: char*. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **root_get**
> root_get()

Fetch all records from the database

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()

try:
    # Fetch all records from the database
    api_instance.root_get()
except ApiException as e:
    print("Exception when calling DefaultApi->root_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **word_get**
> word_get(word)

Fetch the meaning of a specific word

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
word = 'word_example' # str | The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*.

try:
    # Fetch the meaning of a specific word
    api_instance.word_get(word)
except ApiException as e:
    print("Exception when calling DefaultApi->word_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **word** | **str**| The sanskrit word transliterated into roman, for example, rajan. Wildcards allowed; example: *aj*. | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

